# COMMODEX AI 📊
### MCX · NSE Intelligence Terminal

---

## 🚀 Deploy to Vercel in 5 Minutes

### Option A — Drag & Drop (Easiest)
1. Go to **vercel.com** and sign up free
2. Click **"Add New Project"**
3. Click **"Upload"** and drag this entire folder
4. Click **Deploy** — done! ✅

### Option B — GitHub (Recommended for updates)
1. Upload this folder to a new GitHub repo
2. Go to **vercel.com** → Import from GitHub
3. Select your repo → Deploy

---

## 📱 Install on iPhone
1. Open your Vercel URL in **Safari**
2. Tap **Share ↑** → **"Add to Home Screen"**
3. Tap **Add** — runs like a native app!

---

## 🔗 Share With Friends
Just send them your Vercel URL — they can install it too!

---

## ⚙️ Features
- Live MCX & NSE commodity tracker
- Volatility ranking (auto-updates every 15s)
- AI-powered entry/exit signals (Claude AI)
- BUY / SELL / HOLD recommendations
- iPhone PWA — installs like native app
- Live alerts for high volatility

---

Built with React + Vite + Claude AI
