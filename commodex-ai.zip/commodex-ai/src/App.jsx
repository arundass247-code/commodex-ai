import { useState, useEffect, useCallback } from "react";

const COMMODITIES = [
  { symbol: "CRUDEOIL",   name: "Crude Oil",    exchange: "MCX", unit: "₹/bbl",   basePrice: 8049,  sector: "Energy" },
  { symbol: "GOLD",       name: "Gold",          exchange: "MCX", unit: "₹/10g",  basePrice: 89450, sector: "Metals" },
  { symbol: "SILVER",     name: "Silver",        exchange: "MCX", unit: "₹/kg",   basePrice: 98200, sector: "Metals" },
  { symbol: "NATURALGAS", name: "Natural Gas",   exchange: "MCX", unit: "₹/mmbtu",basePrice: 234,   sector: "Energy" },
  { symbol: "COPPER",     name: "Copper",        exchange: "MCX", unit: "₹/kg",   basePrice: 812,   sector: "Metals" },
  { symbol: "NICKEL",     name: "Nickel",        exchange: "MCX", unit: "₹/kg",   basePrice: 1456,  sector: "Metals" },
  { symbol: "ALUMINIUM",  name: "Aluminium",     exchange: "MCX", unit: "₹/kg",   basePrice: 234,   sector: "Metals" },
  { symbol: "ZINC",       name: "Zinc",          exchange: "MCX", unit: "₹/kg",   basePrice: 287,   sector: "Metals" },
  { symbol: "NIFTY",      name: "Nifty 50",      exchange: "NSE", unit: "₹",      basePrice: 22450, sector: "Index"  },
  { symbol: "BANKNIFTY",  name: "Bank Nifty",    exchange: "NSE", unit: "₹",      basePrice: 48200, sector: "Index"  },
];

function simulatePriceData(basePrice) {
  const volatility = (Math.random() * 4 - 2);
  const change = basePrice * (volatility / 100);
  const price = basePrice + change;
  return {
    price:           parseFloat(price.toFixed(2)),
    change:          parseFloat(change.toFixed(2)),
    changePct:       parseFloat(volatility.toFixed(2)),
    high:            parseFloat((price + Math.abs(price * 0.008)).toFixed(2)),
    low:             parseFloat((price - Math.abs(price * 0.007)).toFixed(2)),
    volume:          Math.floor(Math.random() * 50000 + 5000),
    volatilityScore: parseFloat((Math.abs(volatility) * 10 + Math.random() * 20).toFixed(1)),
  };
}

function MiniChart({ positive }) {
  const points = Array.from({ length: 20 }, (_, i) => ({
    x: i, y: 50 + (Math.random() - (positive ? 0.4 : 0.6)) * 30,
  }));
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x * 4} ${p.y}`).join(" ");
  const color = positive ? "#00ff88" : "#ff4466";
  return (
    <svg width="80" height="32" viewBox="0 0 80 100" preserveAspectRatio="none">
      <defs>
        <linearGradient id={`g${positive}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={path + " L 76 100 L 0 100 Z"} fill={`url(#g${positive})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="2" />
    </svg>
  );
}

function VolatilityBar({ score }) {
  const color = score > 60 ? "#ff4466" : score > 35 ? "#ffaa00" : "#00ff88";
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
      <div style={{ flex: 1, height: "4px", background: "#1a1f2e", borderRadius: "2px", overflow: "hidden" }}>
        <div style={{ width: `${Math.min(score, 100)}%`, height: "100%", background: color, borderRadius: "2px", transition: "width 1s ease", boxShadow: `0 0 6px ${color}` }} />
      </div>
      <span style={{ color, fontSize: "11px", fontFamily: "monospace", minWidth: "32px" }}>{score.toFixed(0)}</span>
    </div>
  );
}

function AlertBadge({ signal }) {
  const map = {
    BUY:   { bg: "#00ff8820", border: "#00ff88", text: "#00ff88" },
    SELL:  { bg: "#ff446620", border: "#ff4466", text: "#ff4466" },
    HOLD:  { bg: "#ffaa0020", border: "#ffaa00", text: "#ffaa00" },
    WATCH: { bg: "#4488ff20", border: "#4488ff", text: "#4488ff" },
  };
  const c = map[signal] || map.WATCH;
  return (
    <span style={{ background: c.bg, border: `1px solid ${c.border}`, color: c.text, padding: "2px 8px", borderRadius: "4px", fontSize: "10px", fontWeight: "700", letterSpacing: "1px", fontFamily: "monospace" }}>
      {signal}
    </span>
  );
}

function AnalysisCards({ text }) {
  const get = (label) => {
    const m = text.match(new RegExp(`${label}[:\\s]+([^\\n]+)`, "i"));
    return m ? m[1].trim() : "—";
  };
  const signal = get("SIGNAL");
  const entry  = get("ENTRY");
  const t1     = get("TARGET 1");
  const t2     = get("TARGET 2");
  const stop   = get("STOP LOSS");
  const why    = get("WHY");
  const risk   = get("RISK");
  const sc     = signal.includes("BUY") ? "#00ff88" : signal.includes("SELL") ? "#ff4466" : "#ffaa00";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <div style={{ background: `${sc}15`, border: `2px solid ${sc}`, borderRadius: "10px", padding: "14px 20px", textAlign: "center" }}>
        <div style={{ fontSize: "11px", color: sc, letterSpacing: "3px", marginBottom: "4px" }}>RECOMMENDATION</div>
        <div style={{ fontSize: "28px", fontWeight: "700", color: sc, letterSpacing: "4px" }}>{signal}</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
        {[
          { label: "📍 ENTRY",     value: entry, color: "#66aaff" },
          { label: "🛡️ STOP LOSS", value: stop,  color: "#ff5577" },
          { label: "🎯 TARGET 1",  value: t1,    color: "#00ff88" },
          { label: "🎯 TARGET 2",  value: t2,    color: "#00cc66" },
        ].map(item => (
          <div key={item.label} style={{ background: "#0d1830", border: `1px solid ${item.color}30`, borderRadius: "8px", padding: "12px" }}>
            <div style={{ fontSize: "9px", color: "#aabbcc", letterSpacing: "1px", marginBottom: "5px" }}>{item.label}</div>
            <div style={{ fontSize: "16px", fontWeight: "700", color: item.color }}>{item.value}</div>
          </div>
        ))}
      </div>
      <div style={{ background: "#0d1830", border: "1px solid #1a2a40", borderRadius: "8px", padding: "12px" }}>
        <div style={{ fontSize: "9px", color: "#aabbcc", letterSpacing: "1px", marginBottom: "5px" }}>⚡ WHY</div>
        <div style={{ fontSize: "13px", color: "#ffffff", lineHeight: "1.5" }}>{why}</div>
      </div>
      <div style={{ background: "#1a0a10", border: "1px solid #ff446630", borderRadius: "8px", padding: "12px" }}>
        <div style={{ fontSize: "9px", color: "#ff8899", letterSpacing: "1px", marginBottom: "5px" }}>⚠️ RISK</div>
        <div style={{ fontSize: "13px", color: "#ffffff", lineHeight: "1.5" }}>{risk}</div>
      </div>
    </div>
  );
}

export default function App() {
  const [commodities, setCommodities] = useState([]);
  const [selected,    setSelected]    = useState(null);
  const [analysis,    setAnalysis]    = useState("");
  const [loading,     setLoading]     = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [alerts,      setAlerts]      = useState([]);
  const [activeTab,   setActiveTab]   = useState("dashboard");
  const [filter,      setFilter]      = useState("ALL");

  const refreshData = useCallback(() => {
    const updated = COMMODITIES.map(c => {
      const d = simulatePriceData(c.basePrice);
      const signal = d.volatilityScore > 60 ? (d.changePct > 0 ? "SELL" : "BUY") : d.volatilityScore > 35 ? "WATCH" : "HOLD";
      return { ...c, ...d, signal };
    }).sort((a, b) => b.volatilityScore - a.volatilityScore);
    setCommodities(updated);
    setLastUpdated(new Date());
    const hv = updated.filter(c => c.volatilityScore > 55);
    if (hv.length > 0) {
      setAlerts(prev => [
        { id: Date.now(), message: `⚡ HIGH VOLATILITY: ${hv[0].name} — Score ${hv[0].volatilityScore}`, time: new Date(), type: hv[0].signal },
        ...prev.slice(0, 9),
      ]);
    }
  }, []);

  useEffect(() => { refreshData(); const t = setInterval(refreshData, 15000); return () => clearInterval(t); }, [refreshData]);

  const getAIAnalysis = async (commodity) => {
    setSelected(commodity); setLoading(true); setAnalysis(""); setActiveTab("analysis");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: `You are a commodity trading assistant for MCX/NSE India. Be VERY brief and simple.

Commodity: ${commodity.name} (${commodity.symbol}) | ${commodity.exchange}
Price: ₹${commodity.price} | Change: ${commodity.changePct > 0 ? "+" : ""}${commodity.changePct}%
High: ₹${commodity.high} | Low: ₹${commodity.low}
Volatility Score: ${commodity.volatilityScore}/100

Reply in EXACTLY this format, nothing more:

SIGNAL: [BUY / SELL / HOLD]

ENTRY: ₹[price]
TARGET 1: ₹[price]
TARGET 2: ₹[price]
STOP LOSS: ₹[price]

WHY: [One simple sentence. Max 15 words.]
RISK: [One simple sentence. Max 10 words.]

Use plain simple English. No jargon. No long explanations.` }],
        }),
      });
      const data = await res.json();
      setAnalysis(data.content?.map(b => b.text || "").join("") || "Analysis unavailable.");
    } catch { setAnalysis("⚠️ Unable to fetch AI analysis. Please check your connection."); }
    finally  { setLoading(false); }
  };

  const filtered    = commodities.filter(c => filter === "ALL" || c.exchange === filter || c.sector === filter);
  const topVolatile = commodities[0];

  const S = {
    app:      { minHeight: "100vh", background: "#080c14", color: "#fff", fontFamily: "'IBM Plex Mono','Courier New',monospace", position: "relative" },
    grid:     { position: "fixed", inset: 0, backgroundImage: "linear-gradient(rgba(0,180,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,180,255,0.03) 1px,transparent 1px)", backgroundSize: "40px 40px", pointerEvents: "none" },
    header:   { padding: "20px 24px 0", borderBottom: "1px solid #1a2a40", background: "linear-gradient(180deg,#0a1020 0%,transparent 100%)" },
    hTop:     { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px", flexWrap: "wrap", gap: "12px" },
    logo:     { display: "flex", alignItems: "center", gap: "12px" },
    logoIcon: { width: "36px", height: "36px", background: "linear-gradient(135deg,#0066ff,#00aaff)", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px", boxShadow: "0 0 20px #0066ff50" },
    badge:    { background: "#0a1525", border: "1px solid #1a3a60", padding: "6px 12px", borderRadius: "6px", fontSize: "10px", color: "#66bbff", letterSpacing: "1px" },
    tabs:     { display: "flex", marginBottom: "-1px" },
    tab:      (a) => ({ padding: "10px 20px", fontSize: "11px", letterSpacing: "1px", cursor: "pointer", border: "none", background: "transparent", color: a ? "#00aaff" : "#aabbcc", borderBottom: a ? "2px solid #00aaff" : "2px solid transparent", transition: "all 0.2s", fontFamily: "inherit" }),
    body:     { padding: "20px 24px" },
    sRow:     { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(140px,1fr))", gap: "12px", marginBottom: "20px" },
    sCard:    (c) => ({ background: "#0a1220", border: `1px solid ${c}40`, borderRadius: "10px", padding: "14px" }),
    sLbl:     { fontSize: "9px", color: "#fff", letterSpacing: "2px", marginBottom: "6px", fontWeight: "600" },
    sVal:     (c) => ({ fontSize: "22px", fontWeight: "700", color: c }),
    sSub:     { fontSize: "10px", color: "#aabbcc", marginTop: "4px" },
    filters:  { display: "flex", gap: "8px", marginBottom: "16px", flexWrap: "wrap" },
    fBtn:     (a) => ({ padding: "5px 12px", fontSize: "10px", letterSpacing: "1px", cursor: "pointer", border: `1px solid ${a ? "#00aaff" : "#2a3a50"}`, background: a ? "#00aaff15" : "transparent", color: a ? "#00aaff" : "#fff", borderRadius: "4px", fontFamily: "inherit", transition: "all 0.2s" }),
    th:       { fontSize: "9px", letterSpacing: "2px", color: "#fff", padding: "8px 12px", textAlign: "left", borderBottom: "1px solid #1a2a40", fontWeight: "600" },
    tr:       (i) => ({ background: i % 2 === 0 ? "transparent" : "#0a1220", cursor: "pointer" }),
    td:       { padding: "10px 12px", fontSize: "12px", borderBottom: "1px solid #0d1525", color: "#fff" },
    aBox:     { background: "#0a1220", border: "1px solid #1a2a40", borderRadius: "12px", padding: "20px" },
    aItem:    (t) => { const m = { BUY:"#00ff88",SELL:"#ff4466",HOLD:"#ffaa00",WATCH:"#4488ff" }; return { padding: "10px 14px", background: "#0a1220", borderLeft: `3px solid ${m[t]||"#4488ff"}`, borderRadius: "6px", marginBottom: "8px", fontSize: "11px", color: "#fff" }; },
    pulse:    { display: "inline-block", width: "8px", height: "8px", borderRadius: "50%", background: "#00ff88", marginRight: "8px", animation: "pulse 2s infinite" },
    dots:     { display: "flex", gap: "6px", justifyContent: "center", padding: "40px" },
    dot:      (i) => ({ width: "8px", height: "8px", borderRadius: "50%", background: "#0066ff", animation: `bounce 1.2s ${i*0.2}s infinite` }),
  };

  return (
    <div style={S.app}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&display=swap');
        @keyframes pulse  { 0%,100%{opacity:1;box-shadow:0 0 0 0 #00ff8840} 50%{opacity:.7;box-shadow:0 0 0 6px transparent} }
        @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:none} }
        tr:hover td { background: #0d1e35 !important; }
        ::-webkit-scrollbar{width:4px;height:4px}
        ::-webkit-scrollbar-track{background:#080c14}
        ::-webkit-scrollbar-thumb{background:#1a2a40;border-radius:2px}
      `}</style>
      <div style={S.grid} />

      {/* HEADER */}
      <div style={S.header}>
        <div style={S.hTop}>
          <div style={S.logo}>
            <div style={S.logoIcon}>📊</div>
            <div>
              <div style={{ fontSize: "18px", fontWeight: "700", letterSpacing: "2px", color: "#fff" }}>COMMODEX AI</div>
              <div style={{ fontSize: "10px", color: "#aaccee", letterSpacing: "3px" }}>MCX · NSE INTELLIGENCE TERMINAL</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
            <div style={S.badge}><span style={S.pulse} />LIVE · 15s</div>
            <div style={S.badge}>🕐 {lastUpdated.toLocaleTimeString("en-IN")}</div>
            <button onClick={refreshData} style={{ ...S.fBtn(false), background: "#0a2040", borderColor: "#0044aa" }}>⟳ REFRESH</button>
          </div>
        </div>
        <div style={S.tabs}>
          {[{ k:"dashboard",l:"📊 DASHBOARD"},{ k:"analysis",l:"🤖 AI ANALYSIS"},{ k:"alerts",l:`🔔 ALERTS (${alerts.length})`}].map(t=>(
            <button key={t.k} style={S.tab(activeTab===t.k)} onClick={()=>setActiveTab(t.k)}>{t.l}</button>
          ))}
        </div>
      </div>

      <div style={S.body}>

        {/* DASHBOARD */}
        {activeTab === "dashboard" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={S.sRow}>
              {[
                { label:"TOP VOLATILE", val: topVolatile?.symbol||"—", sub:`${topVolatile?.exchange} · Score ${topVolatile?.volatilityScore}`, color:"#00ff88" },
                { label:"SELL SIGNALS", val: commodities.filter(c=>c.signal==="SELL").length, sub:"Active opportunities", color:"#ff4466" },
                { label:"BUY SIGNALS",  val: commodities.filter(c=>c.signal==="BUY").length,  sub:"Active opportunities", color:"#00ff88" },
                { label:"WATCH LIST",   val: commodities.filter(c=>c.signal==="WATCH").length, sub:"Monitoring needed",    color:"#ffaa00" },
              ].map(item=>(
                <div key={item.label} style={S.sCard(item.color)}>
                  <div style={S.sLbl}>{item.label}</div>
                  <div style={S.sVal(item.color)}>{item.val}</div>
                  <div style={S.sSub}>{item.sub}</div>
                </div>
              ))}
            </div>

            <div style={S.filters}>
              {["ALL","MCX","NSE","Energy","Metals"].map(f=>(
                <button key={f} style={S.fBtn(filter===f)} onClick={()=>setFilter(f)}>{f}</button>
              ))}
            </div>

            <div style={{ overflowX: "auto" }}>
              <table style={{ width:"100%", borderCollapse:"collapse" }}>
                <thead>
                  <tr>{["#","COMMODITY","PRICE","CHG%","H / L","VOLATILITY","SIGNAL","CHART","ACTION"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr>
                </thead>
                <tbody>
                  {filtered.map((c,i)=>(
                    <tr key={c.symbol} style={S.tr(i)} onClick={()=>getAIAnalysis(c)}>
                      <td style={{...S.td,color:"#aabbcc",fontSize:"10px"}}>{i+1}</td>
                      <td style={S.td}>
                        <div style={{fontWeight:"600",color:"#fff",letterSpacing:"1px"}}>{c.symbol}</div>
                        <div style={{fontSize:"10px",color:"#aabbcc"}}>{c.exchange} · {c.sector}</div>
                      </td>
                      <td style={{...S.td,fontWeight:"700"}}>{c.unit?.split("/")[0]}{c.price?.toLocaleString("en-IN")}</td>
                      <td style={{...S.td,color:c.changePct>=0?"#00ff88":"#ff4466",fontWeight:"600"}}>{c.changePct>=0?"▲":"▼"} {Math.abs(c.changePct)}%</td>
                      <td style={{...S.td,fontSize:"10px"}}>
                        <div style={{color:"#00ee77"}}>H {c.high?.toLocaleString("en-IN")}</div>
                        <div style={{color:"#ff5577"}}>L {c.low?.toLocaleString("en-IN")}</div>
                      </td>
                      <td style={{...S.td,minWidth:"120px"}}><VolatilityBar score={c.volatilityScore}/></td>
                      <td style={S.td}><AlertBadge signal={c.signal}/></td>
                      <td style={S.td}><MiniChart positive={c.changePct>=0}/></td>
                      <td style={S.td}>
                        <button onClick={(e)=>{e.stopPropagation();getAIAnalysis(c);}} style={{padding:"4px 10px",background:"#0a2040",border:"1px solid #0044aa",color:"#4499ff",borderRadius:"4px",fontSize:"10px",cursor:"pointer",fontFamily:"inherit"}}>
                          🤖 ANALYSE
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* AI ANALYSIS */}
        {activeTab === "analysis" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            {selected ? (
              <>
                <div style={{display:"flex",gap:"12px",marginBottom:"16px",alignItems:"center",flexWrap:"wrap"}}>
                  <div style={{fontSize:"18px",fontWeight:"700",color:"#fff",letterSpacing:"2px"}}>{selected.symbol}</div>
                  <AlertBadge signal={selected.signal}/>
                  <div style={{fontSize:"12px",color:"#aabbcc"}}>{selected.exchange} · Volatility: {selected.volatilityScore}</div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(110px,1fr))",gap:"10px",marginBottom:"20px"}}>
                  {[
                    {label:"PRICE",   value:`${selected.unit?.split("/")[0]}${selected.price?.toLocaleString("en-IN")}`, color:"#fff"},
                    {label:"CHANGE",  value:`${selected.changePct>=0?"+":""}${selected.changePct}%`, color:selected.changePct>=0?"#00ff88":"#ff4466"},
                    {label:"DAY HIGH",value:selected.high?.toLocaleString("en-IN"), color:"#00ee77"},
                    {label:"DAY LOW", value:selected.low?.toLocaleString("en-IN"),  color:"#ff5577"},
                    {label:"VOLUME",  value:selected.volume?.toLocaleString("en-IN"),color:"#66aaff"},
                  ].map(item=>(
                    <div key={item.label} style={{background:"#0a1220",border:"1px solid #1a2a40",borderRadius:"8px",padding:"12px"}}>
                      <div style={{fontSize:"8px",color:"#fff",letterSpacing:"2px",marginBottom:"4px",fontWeight:"600"}}>{item.label}</div>
                      <div style={{fontSize:"14px",fontWeight:"700",color:item.color}}>{item.value}</div>
                    </div>
                  ))}
                </div>
                <div style={S.aBox}>
                  <div style={{fontSize:"9px",letterSpacing:"3px",color:"#aabbcc",marginBottom:"16px"}}>🤖 AI ANALYSIS · POWERED BY CLAUDE</div>
                  {loading ? (
                    <div style={S.dots}>{[0,1,2].map(i=><div key={i} style={S.dot(i)}/>)}</div>
                  ) : analysis ? (
                    <AnalysisCards text={analysis}/>
                  ) : null}
                </div>
              </>
            ) : (
              <div style={{textAlign:"center",padding:"60px 20px"}}>
                <div style={{fontSize:"40px",marginBottom:"16px"}}>🤖</div>
                <div style={{fontSize:"14px",letterSpacing:"2px",color:"#fff"}}>SELECT A COMMODITY FROM DASHBOARD</div>
                <div style={{fontSize:"11px",marginTop:"8px",color:"#aabbcc"}}>Click any row or ANALYSE to get AI entry/exit signals</div>
              </div>
            )}
          </div>
        )}

        {/* ALERTS */}
        {activeTab === "alerts" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"16px"}}>
              <div style={{fontSize:"11px",letterSpacing:"2px",color:"#fff"}}>LIVE ALERT FEED</div>
              <button onClick={()=>setAlerts([])} style={S.fBtn(false)}>CLEAR ALL</button>
            </div>
            {alerts.length===0 ? (
              <div style={{textAlign:"center",padding:"60px"}}>
                <div style={{fontSize:"30px",marginBottom:"12px"}}>🔔</div>
                <div style={{fontSize:"12px",color:"#fff"}}>NO ALERTS YET — REFRESHES EVERY 15s</div>
              </div>
            ) : alerts.map(a=>(
              <div key={a.id} style={S.aItem(a.type)}>
                <div style={{marginBottom:"4px"}}>{a.message}</div>
                <div style={{fontSize:"9px",color:"#aabbcc"}}>{a.time.toLocaleTimeString("en-IN")}</div>
              </div>
            ))}
            <div style={{marginTop:"24px",padding:"16px",background:"#0a1220",border:"1px solid #1a2a40",borderRadius:"10px"}}>
              <div style={{fontSize:"9px",letterSpacing:"2px",color:"#fff",marginBottom:"12px",fontWeight:"600"}}>📱 ADD TO iPHONE HOME SCREEN</div>
              <div style={{fontSize:"12px",color:"#ddeeee",lineHeight:"2"}}>
                1. Open this app in <span style={{color:"#00aaff"}}>Safari</span> on your iPhone<br/>
                2. Tap <span style={{color:"#00aaff"}}>Share ↑</span> at the bottom<br/>
                3. Tap <span style={{color:"#00aaff"}}>"Add to Home Screen"</span><br/>
                4. Tap <span style={{color:"#00aaff"}}>Add</span> ✅ Done!
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
